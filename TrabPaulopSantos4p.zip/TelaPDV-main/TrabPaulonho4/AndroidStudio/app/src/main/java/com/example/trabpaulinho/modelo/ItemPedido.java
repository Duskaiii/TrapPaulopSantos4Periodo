package com.example.trabpaulinho.modelo;

public class ItemPedido {

    private int codigoPedido;
    private Produto produto;
    private int quantidade;
    private double vlrVenda;

    public ItemPedido() {
    }

    public ItemPedido(int codigoPedido, Produto produto, int quantidade) {
        this.codigoPedido = codigoPedido;
        this.produto = produto;
        this.quantidade = quantidade;
    }

    public int getCodigoPedido() {
        return codigoPedido;
    }

    public void setCodigoPedido(int codigoPedido) {
        this.codigoPedido = codigoPedido;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getVlrVenda() {
        return vlrVenda;
    }

    public void setVlrVenda(double vlrVenda) {
        this.vlrVenda = vlrVenda;
    }
}
